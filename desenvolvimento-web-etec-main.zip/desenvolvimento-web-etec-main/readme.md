Curso de Desenvolvimento de Sistemas Integrado ao Ensino Médio, em uma Escola Técnica Estadual (ETEC).

Projetos do 1º ano feitos em dupla com [LuuAbaru](https://github.com/LuuAbaru)
